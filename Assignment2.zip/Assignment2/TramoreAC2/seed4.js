var mongoose = require('mongoose');
mongoose.connect('mongodb://test:ewd16@ds011412.mlab.com:11412/tramoreacapp_db', function(err, db) {
if(!err) {
  console.log("We are connected");
  mongoDb = db;
}
else
{
    console.log("Unable to connect to the db");
}
});

    var Post = require('./api/fixtures/fixtures.model');

    Post.find({}).remove(function() {
      Post.create({
                        "race": "Splashworld 10K 2016",
                        "type": "Run/Walk 10KM",
                        "date": "Apr 10, 2016",
                        "county": "Waterford",
                        "registration": "http://www.totaltiming.ie/event/splashworld-10k-2016/",
                        "imageUrl": "images/Splashworld10K.jpg"
                        },
                        {
                        "race": "Bluewall Waterford to Tramore 7.5 Mile 2016",
                        "type": "Run 7.5 Mile",
                        "date": "Apr 30, 2016",
                        "county": "Waterford",
                        "registration": "http://www.totaltiming.ie/event/bluewall-waterford-to-tramore-7-5-mile-2016",
                        "imageUrl": "images/WAC.jpg"
                        },
                        {
                        "race": "Waterford Viking Marathon 2016",
                        "type": "Run Full, Half, and Quarter Marathon",
                        "date": "Jun 25, 2016",
                        "county": "Waterford",
                        "registration": "http://www.totaltiming.ie/event/waterford-viking-marathon-2016/",
                        "imageUrl": "images/WVM.jpg", 
                        },
                        {
                        "race": "Great Limerick Run",
                        "type": "Run Full, Half, and 6 miles",
                        "date": "May 01, 2016",
                        "county": "Limerick",
                        "registration": "http://www.greatlimerickrun.com/register/",
                        "imageUrl": "images/GLRun.jpg", 
                        }, function() {
          process.exit()
        });
    });