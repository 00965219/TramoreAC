var _ = require('lodash')
var member = require('./members.model');  // NEW
  
function handleError(res, err) {
      return res.send(500, err);
    }

    // Get list of members
    exports.index = function(req, res) {
      member.find(function (err, members) {
        if(err) { return handleError(res, err); }
        return res.json(200, members);
      });
    } ;

    // Creates a new member in datastore.
    exports.create = function(req, res) {
      member.create(req.body, function(err, member) {
        if(err) { return handleError(res, err); }
        return res.json(201, member);
      });
    };

// Update an existing member in datastore.
  exports.update = function(req, res) {
     member.findById(req.params.id, function (err, member) {
       member.race =  req.body.race
       member.date = req.body.date
       member.county = req.body.county
       member.registration = req.body.registration
       member.imageUrl = req.body.imageUrl
          member.save(function (err) {
              if(err) { return handleError(res, err); }
              return res.json(200, member);
          });
      });
  };


// Deletes a customer from datastore.
exports.destroy = function(req, res) {
    member.findById(req.params.id, function (err, member) {
    if(err) { return handleError(res, err); }
    if(!member) { return res.send(404); }
    member.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.send(204);
    });
  });
};
