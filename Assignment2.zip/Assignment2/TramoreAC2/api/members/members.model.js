var mongoose = require('mongoose')
    var Schema = mongoose.Schema;

    var MemberSchema = new Schema({
      name: String,
      username: String,
      email_address: String,
      phone_number: String,
      imageUrl: String
    });

   module.exports = mongoose.model('members', MemberSchema);


