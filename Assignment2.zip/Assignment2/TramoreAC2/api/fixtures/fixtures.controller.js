/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/posts              ->  index
 * POST    /api/posts              ->  create
 * GET     /api/posts/:id          ->  show
 * PUT     /api/posts/:id          ->  update
 * DELETE  /api/posts/:id          ->  destroy
 */

var _ = require('lodash')
var fixture = require('./fixtures.model');  // NEW
  
function handleError(res, err) {
      return res.send(500, err);
    }

    // Get list of fixtures
    exports.index = function(req, res) {
      fixture.find(function (err, fixtures) {
        if(err) { return handleError(res, err); }
        return res.json(200, fixtures);
      });
    } ;

    // Creates a new fixture in datastore.
    exports.create = function(req, res) {
      fixture.create(req.body, function(err, fixture) {
        if(err) { return handleError(res, err); }
        return res.json(201, fixture);
      });
    };

// Update an existing fixture in datastore.
  exports.update = function(req, res) {
     fixture.findById(req.params.id, function (err, fixture) {
       fixture.race =  req.body.race
       fixture.date = req.body.date
       fixture.county = req.body.county
       fixture.registration = req.body.registration
       fixture.imageUrl = req.body.imageUrl
          fixture.save(function (err) {
              if(err) { return handleError(res, err); }
              return res.json(200, fixture);
          });
      });
  };


// Deletes a customer from datastore.
exports.destroy = function(req, res) {
    fixture.findById(req.params.id, function (err, fixture) {
    if(err) { return handleError(res, err); }
    if(!fixture) { return res.send(404); }
    fixture.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.send(204);
    });
  });
};

