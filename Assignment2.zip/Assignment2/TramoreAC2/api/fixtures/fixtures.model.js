var mongoose = require('mongoose')
    var Schema = mongoose.Schema;

    var FixtureSchema = new Schema({
      race: String,
      type: String,
      date: String,
      county: String,
      registration: String,
      imageUrl: String,

    });

   module.exports = mongoose.model('fixtures', FixtureSchema);

