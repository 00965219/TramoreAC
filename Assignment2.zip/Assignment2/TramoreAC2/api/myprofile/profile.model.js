var mongoose = require('mongoose')
    var Schema = mongoose.Schema;

    var ProfileSchema = new Schema({
      name: String,
      username: String,
      email_address: String,
      phone_number: String,
      imageUrl: String
    });

    module.exports = mongoose.model('profiles', ProfileSchema);