var _ = require('lodash')
var Profile = require('./profile.model'); 
  
function handleError(res, err) {
      return res.send(500, err);
    }

// Get profile
exports.index = function(req, res) {
      Profile.find(function (err, profiles) {
        if(err) { return handleError(res, err); }
        return res.json(200, profiles);
      });
    } ;

// Creates a new profile in datastore.
exports.create = function(req, res) {
      Profile.create(req.body, function(err, profile) {
        if(err) { return handleError(res, err); }
        return res.json(201, profile);
      });
    };

    // Update an existing profile in the database.
    exports.update = function(req, res) {
       Profile.findById(req.params.id, function (err, profile) {
            profile.name = req.body.name
            profile.username = req.body.username
            profile.email_address = req.body.email_address
            profile.phone_number = req.body.phone_number
            profile.imageUrl = req.body.imageUrl
            profile.save(function (err) {
                if(err) { return handleError(res, err); }
                return res.send(200, 'Update successful');
            });
        });
     }
