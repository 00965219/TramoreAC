var express = require('express');
var controller = require('./profiles.controller');

var router = express.Router();

router.get('/', controller.index);
router.post('/', controller.create);
router.put('/:id', controller.update);

module.exports = router;