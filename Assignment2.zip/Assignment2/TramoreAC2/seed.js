var mongoose = require('mongoose');
mongoose.connect('mongodb://test:ewd16@ds011412.mlab.com:11412/tramoreacapp_db', function(err, db) {
if(!err) {
  console.log("We are connected");
  mongoDb = db;
}
else
{
    console.log("Unable to connect to the db");
}
});

    var Post = require('./api/post/post.model');

    Post.find({}).remove(function() {
      Post.create(  { 
                    "title" : "Favorites Advance at IAAF World Indoor Championships",
                    "id" : "1",
                    "link" : "http://running.competitor.com/2016/03/news/146858_146858",
                    "username" : "comara",
                    "comments" : [],
                    "upvotes" : "10"
                  },
                 { 
                    "title" : "10 Running Shoe Terms You Need to Know",
                    "id" : "2",
                    "link" : "http://running.competitor.com/2015/04/photos/10-running-shoe-terms-you-need-to-know_125915",
                    "username" : "notme",
                    "comments" : [],
                    "upvotes" : "12"
                  },
                  { 
                    "title" : '10 Exercises to Treat IT Band Syndrome',
                    "id" : "3",
                    "link" : "http://running.competitor.com/2015/03/injury-prevention/10-exercises-to-treat-it-band-syndrome_125083?utm_medium=whats-hot",
                    "username" : "notme",
                    "comments" : [],
                    "upvotes" : "12"
                  },
                  { 
                    "title" : "Big Weekend of Action for Ireland’s Elite",
                    "id" : "4",
                    "link" : "http://www.runireland.com/news/big-weekend-action-ireland%E2%80%99s-elite-rose-anne-galligan-leads-charge-ireland%E2%80%99s-elite-athletes-hea",
                    "username" : "mcowman",  
                    "comments" : [],
                    "upvotes" : "2"
                  }, function() {
          process.exit()
        });
    });