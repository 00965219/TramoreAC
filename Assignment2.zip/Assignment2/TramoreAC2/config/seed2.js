var mongoose = require('mongoose');
mongoose.connect('mongodb://test:ewd16@ds011412.mlab.com:11412/tramoreacapp_db', function(err, db) {
if(!err) {
  console.log("We are connected");
  mongoDb = db;
}
else
{
    console.log("Unable to connect to the db");
}
});

    var Post = require('./api/profile/profile.model');

    Post.find({}).remove(function() {
      Post.create(  {
                        name: "Clodagh OMara",
                        username: "clodaghom",
                        email_address: "clodaghom@live.com",
                        phone_number: "087-123456",
                        imageUrl: "images/myprofilepic.jpg", 
                    }, function() {
          process.exit()
        });
    });