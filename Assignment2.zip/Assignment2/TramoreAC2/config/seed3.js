var mongoose = require('mongoose');
mongoose.connect('mongodb://test:ewd16@ds011412.mlab.com:11412/tramoreacapp_db', function(err, db) {
if(!err) {
  console.log("We are connected");
  mongoDb = db;
}
else
{
    console.log("Unable to connect to the db");
}
});

    var Post = require('./api/members/members.model');

    Post.find({}).remove(function() {
      Post.create({
                        name: 'Linford Christie',
                        username: 'lchristie',
                        email_address: 'lchristie@running.com',
                        phone_number: '051-394923',
                        imageUrl: 'images/LinfordChristie.jpg', 
                        },
                        {
                        name: 'Paula Radcliffe',
                        username: 'paularadcliffe73',
                        email_address: 'paularadcliffe73@hotmail.com',
                        phone_number: '087-7704300',
                        imageUrl: 'images/paularadcliffe.jpg', 
                        },
                        {
                        name: 'Usain Bolt',
                        username: 'ubolt1',
                        email_address: 'ubolt1@gmail.com',
                        phone_number: '085-123456',
                        imageUrl: 'images/UsainBolt.jpg', 
                        },
                        {
                        name: 'Sonia OSullivan',
                        username: 'soniaos',
                        email_address: 'soniaos@yahoo.com',
                        phone_number: '083-123456',
                        imageUrl: 'images/soniaosullivan.jpg', 
                   }, function() {
          process.exit()
        });
    });