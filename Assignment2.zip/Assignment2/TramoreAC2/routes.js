module.exports = function(app) {

	app.use('/api/myprofile', require('./api/myprofile'));
   app.use('/api/members', require('./api/members/'));
   app.use('/api/fixtures', require('./api/fixtures'));
   app.use('/api/post', require('./api/post'));
  // app.use('/api/kits', require('./api/kits'));
   
   app.get('/', function (req, res){
   	res.render('index', {});
   });

  // All undefined asset or api routes should return a 404
  app.route('/:url(api|app|assets)/*')
   .get(function(req, res) {
    res.send(404);
  })

};