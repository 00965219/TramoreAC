angular.module('tramoreacApp')
.factory('kitService', ['$http' , function($http){
        var api = {
                getkits : function() {
                    return $http.get('/api/kits')            
                }, 
                getkit : function(kit_id) {  // NEW
                     return $http.get('/api/kits/' + kit_id)
                }
            }
            return api
    }])
