angular.module('tramoreacApp')
.factory('FixtureService', ['$http', function($http){
   var api = {
   getFixtures : function() {
           return $http.get('/api/fixtures')
     },
     addFixture : function(fixture) {
          return $http.post('/api/fixtures',fixture)
     },

    addFixture1 : function(fixture) {
         return $http.post('/api/fixtures',fixture)
    }

     getFixture : function(fixture) {
        return $http.get('/api/fixtures/' + fixture_id )
     },

     deleteFixture: function(fixture) {  // NEW
                     return $http.delete('/api/fixtures/')
                },
             deleteFixture : function(post_id) {  // NEW
                     return $http.delete('api/fixtures/')
                }
  }
  return api
}])


    




