angular.module('tramoreacApp')
.factory('PostsService', ['$http', function($http){
   var api = {
     getPosts : function() {
           return $http.get('/api/post')
     },
     addPost : function(post) {
          return $http.post('/api/post',post)
     },
     addPostComment : function(post_id, comment) {
          return $http.post('/api/post/' + post_id + '/comments' ,
                            comment)
     },
     upvotePost : function(post_id, new_upvote_count ) {
          return $http.post('/api/post/' + post_id + '/upvotes', 
                     {upvotes: new_upvote_count })
     },
     upvotePostComment : function(post_id, comment_id, new_upvote_count ) {
          return $http.post( '/api/post/' +
                      post_id + '/comments/' +  comment_id + '/upvotes', 
                     {upvotes: new_upvote_count })
     },
     getPost : function(post_id) {
        return $http.get('/api/post/' + post_id )
     },
     deleteComment: function(post_id, comment_id) {  // NEW
                     return $http.delete('/api/post/' + post_id + '/comments/' + comment_id)
                },
             deletePost : function(post_id) {  // NEW
                     return $http.delete('api/post/' + post_id)
                }


  }
  return api
}])