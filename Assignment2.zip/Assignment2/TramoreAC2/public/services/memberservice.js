angular.module('tramoreacApp')
.factory('MemberService', ['$http', function($http){
  var api = {
    addFriend1 : function(member) {
         return $http.post('/api/member',member)
    }
  }
  return api
}])