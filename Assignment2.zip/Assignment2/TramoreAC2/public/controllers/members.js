angular.module('tramoreacApp')
.controller('memberController', [
          '$scope', 
          '$http',  
          '$location',
          'MemberService',
          function($scope, $http, $location,CommunityService) { 
        $http.get('/api/members').success(function(members) {
            $scope.members = members;
        });

    $scope.addMember = function($scope){
       {
        $location.path('/addmember');
        }
    }

    $scope.cancelMember = function($scope){
       {
        $location.path("/cancelmember");
        }
    }

    $scope.addMember1 = function() {
        var member = {
        name: $scope.newMember.name,
        username: $scope.newMember.username,
        emailAddress: $scope.newMember.emailAddress,
        phoneNumber: $scope.newMember.phoneNumber,
       imageUpload: $scope.newMember.imageUrl,
         }
        CommunityService.addMember1(member)
          .success(function(added_member) {
             $scope.members.push(added_member);
             $scope.newMember = { };
             $location.path("/members");
          });
    }

      $scope.deleteMember = function(member,index) {
          member.state = "deleted";
         }

      $scope.undoDelete = function(member) {
         member.state = "normal";
      }
      
    $scope.confirmDelete = function(index) {
        $http.delete('/api/members/' + $scope.members[index]._id)
        .success(function() {
                $scope.members.splice(index, 1) 
         });
    }
}])