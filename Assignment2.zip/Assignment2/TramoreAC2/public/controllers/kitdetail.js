angular.module('tramoreacApp')
.controller('kitDetailCtrl', 
         ['$scope', '$location', '$routeParams', 'kitService', 
         function($scope, $location, $routeParams, kitService) {
             kitService.getkit($routeParams.kitId)
                .success(function(data) {
                   $scope.kit = data
                   $scope.img = $scope.kit.images[0]
                   })
                .error(function(err) {
                    $location.path('./kit') 
                  })
             $scope.setImage = function(img) {
                  $scope.img = img
               }
      }])

