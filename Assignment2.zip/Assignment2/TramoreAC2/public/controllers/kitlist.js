angular.module('tramoreacApp')
.controller('kitListCtrl', ['$scope', 'kitService',
      function($scope, kitService) {
             kitService.getkits().success(function(data) {
                   $scope.kits = data
                 })
             $scope.orderProp = 'age';
          }])