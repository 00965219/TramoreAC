angular.module('tramoreacApp')
.controller('FixturesController', [
          '$scope', 
          '$http',  
          '$location',
          'Fixtureservice',
          function($scope, $http, $location,FixtureService) { 
        $http.get('/api/fixtures').success(function(fixtures) {
            $scope.fixtures = fixtures;
        });

    $scope.addFixture = function($scope){
       {
        $location.path('/addfixture');
        }
    }

    $scope.cancelFixture = function($scope){
       {
        $location.path("/cancelfixture");
        }
    }

    $scope.addFixture = function() {
        var fixture = {
        race: $scope.newFixture.race,
        type: $scope.newFixture.type,
        date: $scope.newFixture.date,
        county: $scope.newFixture.county,
        registration: $scope.newFixture.registration,
       imageUpload: $scope.newFixture.imageUrl,
         }
        CommunityService.addFixture1(fixture)
          .success(function(added_fixture) {
             $scope.fixtures.push(added_fixture);
             $scope.newFixture = { };
             $location.path("/fixtures");
          });
    }

        $scope.deleteFixture = function(fixture) {
            fixture.state = "deleted";
           }
        $scope.undoDelete = function(fixture) {
           fixture.state = "normal";
        }

        $scope.confirmDelete = function(index) {
                if ($scope.fixtures[index].state == "deleted") {
                  $scope.fixtures.splice(index, 1)       
                }
              }

    $scope.editFixture = function(fixture) {
              fixture.oldrace = fixture.race;
              fixture.oldtype = fixture.type;
        fixture.olddate = fixture.date;
              fixture.oldcounty = fixture.county;
        fixture.oldregistration = fixture.registration;
              fixture.state = "edit";
            }

        $scope.saveFixture = function(fixture) {
              fixture.state = "normal";
            }

        $scope.cancelEdit = function(fixture) {
              fixture.race = fixture.oldrace;
        fixture.type = fixture.oldtype;
              fixture.date = fixture.olddate;
              fixture.county = fixture.oldcounty;
        fixture.registration = fixture.registration;
              fixture.state = "normal";
            }
    }])