angular.module('tramoreacApp')
.controller('NavController', function ($scope, $location) {
    $scope.isCollapsed = true;
});