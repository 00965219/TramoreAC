angular.module('tramoreacApp')
.controller('myProfileController', [
          '$scope', 
          '$http',   
          function($scope, $http) { 
        $http.get('/api/myprofile').success(function(myprofile) {
            $scope.myprofile = myprofile;
        });
      $scope.editProfile = function(profile) {
        profile.oldName = profile.name;
        profile.oldUsername = profile.username;
        profile.oldEmailAddress = profile.email_address;
        profile.oldPhoneNumber = profile.phone_number;
        profile.oldImage = profile.imageUrl;
        profile.state = "edit";
      }
    $scope.saveProfile = function(profile) {
        $http.put('/api/myprofile/' + profile._id, profile)
            .success(function(updated_profile) {
                  profile.state = "normal";
            });
    }
      $scope.cancelEdit = function(profile) {
        profile.oldName = profile.name;
        profile.oldUsername = profile.username;
        profile.oldEmailAddress = profile.email_address;
        profile.oldPhoneNumber = profile.phone_number;
        profile.oldImage = profile.imageUrl;
        profile.state = "normal";
      }
}])


  
