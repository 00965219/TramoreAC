var app = angular.module('tramoreacApp', ['ngRoute'])

    app.config(['$routeProvider','$locationProvider',
      function($routeProvider, $locationProvider) {
        $locationProvider.html5Mode(true);

        $routeProvider
            .when('/login', {
              templateUrl: 'partials/login.html',
              controller: 'LoginCtrl'
            })
            .when('/logout', {
              templateUrl: 'partials/tramoreac.html',
            })
            .when('/main', {
              templateUrl: 'partials/main.html',
              controller: 'LoginCtrl'
            })
            .when('/myhome', {
              templateUrl: 'partials/main.html',
            })
            .when('/register', {
              templateUrl: 'partials/register.html',
              controller: 'RegisterCtrl',
              directive: 'passwordMatch'
            })
            .when('/tramoreac', {
              templateUrl: 'partials/tramoreac.html',
            })
            .when('/members', {
              templateUrl: 'partials/members.html',
              controller: 'memberController'
            })
            .when('/addmember', {
              templateUrl: 'partials/addmember.html',
              controller: 'memberController'
            })
            .when('/cancelmember', {
              templateUrl: 'partials/members.html',
              controller: 'memberController'
            })
			     .when('/fixtures', {
              templateUrl: 'partials/fixtures.html',
              controller: 'fixturesController'
            })

            .when('/myprofile', {
              templateUrl: 'partials/myprofile.html',
              controller: 'myProfileController'
            })
            .when('/registersuccess', {
              templateUrl: 'partials/register_success.html',
              controller: 'RegisterCtrl'
            })
            .when('/myposts', {
              templateUrl: 'partials/myposts.html',
              controller: 'PostsController'
            })
            .when('/posts/:post_id/comments', {
              controller: 'CommentsController',
              templateUrl: './partials/comments.html'
            })
		  .when('/kits', {
            templateUrl: 'partials/kit-list.html',
            controller: 'kitListCtrl'
          })
          .when('/kits/:kitId', {
            templateUrl: 'partials/kit-detail.html',
            controller: 'kitDetailCtrl'
          })
            .otherwise({
              redirectTo: '/tramoreac'
            })
    }])

   app.controller('LoginCtrl',function($scope, $location, $rootScope){
    $scope.user = {}

    $scope.SubmitForm = function(isValid){
        if(isValid){
            $location.path( "/main");
        }
    }
})

    app.controller('RegisterCtrl', function($scope, $location, $rootScope){
    $scope.user = {};

    $scope.SubmitForm = function(isValid){
        if(isValid){
        $location.path( "/registersuccess");
        }
    }
})

    app.directive('passwordMatch', function () {
    return {
        restrict: 'A',
        scope: true,
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            var firstPasswordID = '#' + attrs.passwordMatch;
            var firstPasswordEl = $(firstPasswordID);
            elem.add(firstPasswordID).on('keyup', function () {
                scope.$apply(function () {
                    console.log(elem.val() === firstPasswordEl.val());
                    ctrl.$setValidity('passwordMatch', elem.val() === firstPasswordEl.val());
                });
            });
        }
    }
})

        
	

	