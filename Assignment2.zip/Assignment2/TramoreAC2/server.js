var express = require('express');
var app = express(); 
var mongoose = require('mongoose');
var fs = require('fs-extra');
var qt = require('quickthumb');

mongoose.connect('mongodb://test:ewd16@ds011412.mlab.com:11412/tramoreacapp_db', function(err, db) {
if(!err) {
  console.log("We are connected");
  mongoDb = db;
}
else
{
    console.log("Unable to connect to the db");
}
});

require('./config/express').addMiddleware(app)
require('./routes')(app)

app.get('*', function(req, res) {
  res.redirect('/#' + req.originalUrl);
});

app.use(express.static(__dirname + '/public'));

app.listen(4000, function() {
  console.log('Express server listening.');
});