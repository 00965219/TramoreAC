var app = angular.module('tramoreacApp', ['ngRoute'])

    app.config(['$routeProvider',
      function($routeProvider) {
        $routeProvider
            .when('/login', {
              templateUrl: 'partials/login.html',
              controller: 'LoginCtrl'
            })
            .when('/logout', {
              templateUrl: 'partials/tramoreac.html',
            })
            .when('/main', {
              templateUrl: 'partials/main.html',
              controller: 'LoginCtrl'
            })
            .when('/myhome', {
              templateUrl: 'partials/main.html',
            })
            .when('/register', {
              templateUrl: 'partials/register.html',
              controller: 'RegisterCtrl',
              directive: 'passwordMatch'
            })
            .when('/tramoreac', {
              templateUrl: 'partials/tramoreac.html',
            })
            .when('/members', {
              templateUrl: 'partials/members.html',
              controller: 'memberController'
            })
			     .when('/fixtures', {
              templateUrl: 'partials/fixtures.html',
              controller: 'fixtureController'
            })
            .when('/myprofile', {
              templateUrl: 'partials/myprofile.html',
              controller: 'myProfileController'
            })
            .when('/registersuccess', {
              templateUrl: 'partials/register_success.html',
              controller: 'RegisterCtrl'
            })
            .when('/myposts', {
              templateUrl: 'partials/myposts.html',
              controller: 'forumController'
            })
            .when('/posts/:post_id/comments', {
              controller: 'CommentsController',
              templateUrl: './partials/comments.html'
            })
		  .when('/kits', {
            templateUrl: 'partials/kit-list.html',
            controller: 'kitListCtrl'
          })
          .when('/kits/:kitId', {
            templateUrl: 'partials/kit-detail.html',
            controller: 'kitDetailCtrl'
          })
            .otherwise({
              redirectTo: '/tramoreac'
            })
    }])

   app.controller('LoginCtrl',function($scope, $location, $rootScope){
    $scope.user = {}

    $scope.SubmitForm = function(isValid){
        if(isValid){
            $location.path( "/main");
        }
    }
})

    app.controller('RegisterCtrl', function($scope, $location, $rootScope){
    $scope.user = {};

    $scope.SubmitForm = function(isValid){
        if(isValid){
        $location.path( "/registersuccess");
        }
    }
})

    app.directive('passwordMatch', function () {
    return {
        restrict: 'A',
        scope: true,
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            var firstPasswordID = '#' + attrs.passwordMatch;
            var firstPasswordEl = $(firstPasswordID);
            elem.add(firstPasswordID).on('keyup', function () {
                scope.$apply(function () {
                    console.log(elem.val() === firstPasswordEl.val());
                    ctrl.$setValidity('passwordMatch', elem.val() === firstPasswordEl.val());
                });
            });
        }
    }
})

        app.controller('myProfileController', ['$scope', function($scope) {
                        $scope.myprofile = [
                        {
                        name: 'Clodagh OMara',
                        username: 'clodaghom',
                        email_address: 'clodaghom@live.com',
                        phone_number: '087-123456',
                        imageUrl: 'images/myprofilepic.jpg', 
                        }
                   ]
        $scope.editProfile = function(profile) {
              profile.oldName = profile.name;
              profile.oldUsername = profile.username;
              profile.oldEmailAddress = profile.email_address;
              profile.oldPhoneNumber = profile.phone_number;
              profile.oldImage = profile.imageUrl;
              profile.state = "edit";
            }
        $scope.saveProfile = function(profile) {
              profile.state = "normal";
            }
        $scope.cancelEdit = function(profile) {
              profile.oldName = profile.name;
              profile.oldUsername = profile.username;
              profile.oldEmailAddress = profile.email_address;
              profile.oldPhoneNumber = profile.phone_number;
              profile.oldImage = profile.imageUrl;
              profile.state = "normal";
            }
    }])

    app.controller('memberController', ['$scope', function($scope) {
                        $scope.members = [
                        {
                        name: 'Linford Christie',
                        username: 'lchristie',
                        email_address: 'lchristie@running.com',
                        phone_number: '051-394923',
                        imageUrl: 'images/LinfordChristie.jpg', 
                        },
                        {
                        name: 'Paula Radcliffe',
                        username: 'paularadcliffe73',
                        email_address: 'paularadcliffe73@hotmail.com',
                        phone_number: '087-7704300',
                        imageUrl: 'images/paularadcliffe.jpg', 
                        },
                        {
                        name: 'Usain Bolt',
                        username: 'ubolt1',
                        email_address: 'ubolt1@gmail.com',
                        phone_number: '085-123456',
                        imageUrl: 'images/UsainBolt.jpg', 
                        },
                        {
                        name: 'Sonia OSullivan',
                        username: 'soniaos',
                        email_address: 'soniaos@yahoo.com',
                        phone_number: '083-123456',
                        imageUrl: 'images/soniaosullivan.jpg', 
                        },
                   ]
        $scope.deleteMember = function(member) {
            member.state = "deleted";
           }
        $scope.undoDelete = function(member) {
           member.state = "normal";
        }
        $scope.confirmDelete = function(index) {
                if ($scope.members[index].state == "deleted") {
                  $scope.members.splice(index, 1)       
                }
              }
		    $scope.editMember = function(member) {
              member.oldName = member.name;
              member.oldusername = member.username;
			  member.oldemail_address = member.email_address
              member.oldPhoneNumber = member.phone_number;
              member.state = "edit";
            }
        $scope.saveContact = function(member) {
              member.state = "normal";
            }
        $scope.cancelEdit = function(member) {
              member.name = member.oldName;
			  member.username = member.oldusername;
              member.email_address = member.oldemail_address;
              member.phone_number = member.oldPhoneNumber;
              member.state = "normal";
            }
    }])
	
  app.controller('fixtureController', ['$scope', function($scope) {
                        $scope.fixtures = [
                        {
                        race: 'Splashworld 10K 2016',
                        type: 'Run/Walk 10KM',
                        date: 'Apr 10, 2016',
                        county: 'Waterford',
						registration: 'http://www.totaltiming.ie/event/splashworld-10k-2016/',
                        imageUrl: 'images/Splashworld10K.jpg', 
                        },
                        {
						race: 'Bluewall Waterford to Tramore 7.5 Mile 2016',
                        type: 'Run 7.5 Mile',
                        date: 'Apr 30, 2016',
                        county: 'Waterford',
						registration: 'http://www.totaltiming.ie/event/bluewall-waterford-to-tramore-7-5-mile-2016/',
                        imageUrl: 'images/WAC.jpg', 
                        },
                        {
                        race: 'Waterford Viking Marathon 2016',
                        type: 'Run Full, Half, and Quarter Marathon',
                        date: 'Jun 25, 2016',
                        county: 'Waterford',
						registration: 'http://www.totaltiming.ie/event/waterford-viking-marathon-2016/',
                        imageUrl: 'images/WVM.jpg', 
                        },
                        {
                        race: 'Great Limerick Run',
                        type: 'Run Full, Half, and 6 miles',
                        date: 'May 01, 2016',
                        county: 'Limerick',
						registration: 'http://www.greatlimerickrun.com/register/',
                        imageUrl: 'images/GLRun.jpg', 
                        },
                   ]
        $scope.deleteFixture = function(fixture) {
            fixture.state = "deleted";
           }
        $scope.undoDelete = function(fixture) {
           fixture.state = "normal";
        }
        $scope.confirmDelete = function(index) {
                if ($scope.fixtures[index].state == "deleted") {
                  $scope.fixtures.splice(index, 1)       
                }
              }
		$scope.editFixture = function(fixture) {
              fixture.oldrace = fixture.race;
              fixture.oldtype = fixture.type;
			  fixture.olddate = fixture.date;
              fixture.oldcounty = fixture.county;
			  fixture.oldregistration = fixture.registration;
              fixture.state = "edit";
            }
        $scope.saveContact = function(fixture) {
              fixture.state = "normal";
            }
        $scope.cancelEdit = function(fixture) {
              fixture.race = fixture.oldrace;
			  fixture.type = fixture.oldtype;
              fixture.date = fixture.olddate;
              fixture.county = fixture.oldcounty;
			  fixture.registration = fixture.registration;
              fixture.state = "normal";
            }
    }])
	

	
	
    app.controller('forumController', ['$scope','PostsService', 
           function($scope,PostsService) {
              $scope.posts = PostsService.getPosts()   // CHANGE
            $scope.incrementUpvotes = function(post) {
           post.upvotes += 1;
          }
      $scope.addPost = function(){
          var new_id = 1 + $scope.posts[$scope.posts.length - 1].id
          $scope.posts.push({
            title: $scope.newPost.title,
            id: new_id,
            link: $scope.newPost.link,
            username : $scope.newPost.username,
            comments : [],
            upvotes: 0
          })
          $scope.newPost = { }
        }
      }
    ])

    app.controller('CommentsController', ['$scope',
       'PostsService', 
       '$routeParams',
       function ($scope,PostsService ,$routeParams) {
             $scope.post = PostsService.getPost($routeParams.post_id)
             $scope.incrementUpvotes = function(comment) {
                  comment.upvotes += 1;
             }
             $scope.addComment = function(){
                $scope.post.comments.push({
                  body: $scope.comment.body,
                  author: $scope.comment.author ,
                  upvotes: 0
                })
                $scope.comment = {} ;
              }
        }])

    app.factory('PostsService', [function(){
         var posts = [ 
                { 
                    title : 'Favorites Advance at IAAF World Indoor Championships',
                    id : 1,
                    link : 'http://running.competitor.com/2016/03/news/146858_146858',
                    username : 'comara',
                    comments : [],
                    upvotes : 10
                  },
                 { 
                    title : '10 Running Shoe Terms You Need to Know',
                    id : 2,
                    link : 'http://running.competitor.com/2015/04/photos/10-running-shoe-terms-you-need-to-know_125915',
                    username : 'notme',
                    comments : [],
                    upvotes : 12
                  },
                  { 
                    title : '10 Exercises to Treat IT Band Syndrome',
                    id : 3,
                    link : 'http://running.competitor.com/2015/03/injury-prevention/10-exercises-to-treat-it-band-syndrome_125083?utm_medium=whats-hot',
                    username : 'notme',
                    comments : [],
                    upvotes : 12
                  },
                  { 
                    title : 'Big Weekend of Action for Ireland’s Elite',
                    id : 4,
                    link : 'http://www.runireland.com/news/big-weekend-action-ireland%E2%80%99s-elite-rose-anne-galligan-leads-charge-ireland%E2%80%99s-elite-athletes-hea',
                    username : 'mcowman',  
                    comments : [],
                    upvotes : 2
                  }
                ]
         var api = {
             getPosts : function() {
                return posts
             },
             getPost : function(id) {
                var result = null
                posts.forEach(function(post){
                   if (post.id == id) {
                      result  = post
                    }
                } )
                return result
             }
          }
          return api
        }])
		
app.controller('kitListCtrl', ['$scope', 'kitService',
      function($scope, kitService) {
             kitService.getkits().success(function(data) {
                   $scope.kits = data
                 })
             $scope.orderProp = 'age';
          }])

app.controller('kitDetailCtrl', 
         ['$scope', '$location', '$routeParams', 'kitService', 
         function($scope, $location, $routeParams, kitService) {
             kitService.getkit($routeParams.kitId)
                .success(function(data) {
                   $scope.kit = data
                   $scope.img = $scope.kit.images[0]
                   })
                .error(function(err) {
                    $location.path('./kit') 
                  })
             $scope.setImage = function(img) {
                  $scope.img = img
               }
      }])

app.factory('kitService', ['$http' , function($http){
        var api = {
                getkits : function() {
                    return $http.get('kits/kits.json')            
                }, 
                getkit : function(id) {  // NEW
                     return $http.get('kits/' + id + '.json')
                }
            }
            return api
    }])